package com.example.demo.exception;

import static org.junit.jupiter.api.Assertions.*;

class ApiErrorTest {

}